//
//  main.swift
//  week02_task_1
//
//

import Foundation

//Holder for the bp data
var diastolicBloodPressures = [[Int]]()

/*
 * Generate some fake data.
 * Data would usually come from a database.
 */
for _ in 0..<100{
    var patientDiastolicPressures = [Int]()
    for _ in 0..<40 {
        /*
         https://www.hackingwithswift.com/articles/102/how-to-generate-random-numbers-in-swift
         */
        patientDiastolicPressures.append(Int.random(in: 60...130))
    }
    diastolicBloodPressures.append(patientDiastolicPressures)
}
//Convert BP's into stats.
let pressureStats = generateArrayStats(data: diastolicBloodPressures)

//print requested stats until user indicates otherwise
repeatedlyPrintRequestedStats(stats: pressureStats)











