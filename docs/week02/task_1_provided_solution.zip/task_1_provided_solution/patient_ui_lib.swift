//
//  ui_lib.swift
//  week02_task_1
//
//

/// Safely and infinitely print out the results for any patient number entered by the user. When the user is done they enter 'done' to exit the loop.
/// - Parameter stats: a two-dimentional Array of Doubles representing the Blood Pressure statistics for all patients.
/// - Complexity: O(1)
func repeatedlyPrintRequestedStats(stats: [[Double]]) {
    while true {
        print("Enter a patient number: 0 to (\(stats.count - 1))")
        let numberAsString = readLine()
        // check if the user is done entering ages
        guard numberAsString != "done" else {
            break
        }
        // make sure they entered a number
        guard let patientNumber = Int(numberAsString!) else {
            print("'\(numberAsString!)' is not a number")
            continue
        }
        guard patientNumber >= 0, patientNumber < pressureStats.count else {
            print("There is no patient number: \(patientNumber)")
            continue
        }
        print("Patient: \(patientNumber) BP Stats: \(pressureStats[patientNumber])")
    }
}
