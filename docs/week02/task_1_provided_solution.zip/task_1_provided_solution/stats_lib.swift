//
//  stats_lib.swift
//  week02_task_1
//
//

/// This function reduces an sub-array's Integer data to an Array of statistics that describe the data in the sub-array.
/// - Parameter data: a two dimentional Array of Ints.
/// - Returns: a two dimentional Array of Doubles containing the mean, max, and min values of each row of input data.
/// - Complexity: O(n^2)
func generateArrayStats(data: [[Int]]) -> [[Double]] {
    // the accumulator starts out as an empty Array of Arrays of Doubles
    let results = data.reduce([[Double]]()) { rowAccumulator, row in
        var mutatableRowAccumulator = rowAccumulator
        var maxValue = -Double.infinity
        var minValue = Double.infinity
        let singleRowSum = row.reduce(0.0) { dataPointAccumulator, anInt in
            let dataPointAsDouble = Double(anInt)
            if maxValue < dataPointAsDouble {
                maxValue = dataPointAsDouble
            }
            if minValue > dataPointAsDouble {
                minValue = dataPointAsDouble
            }
            return dataPointAccumulator + dataPointAsDouble
        }
        mutatableRowAccumulator.append([singleRowSum / Double(row.count), maxValue, minValue])
        return mutatableRowAccumulator
    }
    return results
}
